#pragma once

unsigned int CompressAlpha(const unsigned char *alpha, const unsigned char *palette, unsigned int size, unsigned char **compressed);


